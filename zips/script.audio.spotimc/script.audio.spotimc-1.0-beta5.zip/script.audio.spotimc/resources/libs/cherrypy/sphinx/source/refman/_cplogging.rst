**************************
:mod:`cherrypy._cplogging`
**************************

.. automodule:: cherrypy._cplogging

Classes
=======

.. autoclass:: LogManager
   :members:

.. autoclass:: WSGIErrorHandler
   :members:

