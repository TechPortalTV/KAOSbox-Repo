plugin.video.alluc.api
========================
Welcome to the Alluc API Kodi addon.
For support go to http://forums.tvaddons.ag/.