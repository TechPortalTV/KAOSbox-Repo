plugin.video.myvevo
================


Kodi Addon for VEVO

V3.0.4 add Get Related Videos
V3.0.3 improve add to library
V3.0.2 Added initial version of Add to Library
V3.0.1 Isengard version